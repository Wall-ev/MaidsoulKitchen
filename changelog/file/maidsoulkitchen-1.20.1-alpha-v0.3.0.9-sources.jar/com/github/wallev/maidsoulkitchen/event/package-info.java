@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.wallev.maidsoulkitchen.event;

import net.minecraft.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;