package com.renyigesai.bakeries.api.event;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraftforge.eventbus.api.Event;


public class SnifferDropSeedEvent extends Event {
    private final Level level;
    private final BlockPos blockPos;

    public SnifferDropSeedEvent(Level level, BlockPos blockPos) {
        this.level = level;
        this.blockPos = blockPos;
    }

    public Level getLevel() {
        return level;
    }

    public BlockPos getBlockPos() {
        return blockPos;
    }
}
